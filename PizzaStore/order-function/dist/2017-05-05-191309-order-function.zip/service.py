from __future__ import print_function
from boto3.dynamodb.conditions import Key, Attr

import boto3
import json

print('Loading function')


def respond(err, res=None):
    return {
        'statusCode': '400' if err else '200',
        'body': err.message if err else json.dumps(res),
        'headers': {
            'Content-Type': 'application/json',
        },
    }


def lambda_handler(event, context):

    print("Received event: " + json.dumps(event, indent=2))

    operations = {
        'DELETE': lambda dynamo, x: dynamo.delete_item(**x),
        'GET': lambda dynamo, x: dynamo.scan(**x),
        'POST': lambda dynamo, x: dynamo.put_item(**x),
        'PUT': lambda dynamo, x: dynamo.update_item(**x),
    }

    operation = event['httpMethod']


    if operation in operations:

        if operation == 'GET':
            order_id = event['order_id']
            dynamo = boto3.resource('dynamodb').Table('menu')
            response = dynamo.scan(FilterExpression=Attr('order_id').eq(order_id))
            items = response['Items']
            # print(items)
            return respond(None, items)

        elif operation == 'POST':
            payload = event['body']
            # print(payload)
            menu_table = boto3.resource('dynamodb').Table('menu')
            menu = menu_table.scan(FilterExpression=Attr('menu_id').eq(payload['menu_id']))
            selection = menu['Item']['selection']
            size = menu['Item']['size']

            order_table = boto3.resource('dynamodb').Table('order')
            response = order_table.put_item(
                Item={
                    'menu_id': payload['menu_id'],
                    'order_id': payload['order_id'],
                    'customer_name': payload['customer_name'],
                    'customer_email': payload['customer_email'],
                    'order_status': 'selection',
                    'order': {
                        'selection': selection,
                        'size': size
                    }
                }
            )

            return respond(None, response)
        elif operation == 'PUT':
            input = event['input']
            order_id = event['order_id']
            order_table = boto3.resource('dynamodb').Table('order')
            order = order_table.scan(FilterExpression=Attr('order_id').eq(order_id))
            if order['Item']['order_status'] == 'selection':
                selection_list = order['Item']['order']['selection']
                response = order_table.update_item(
                    Key={
                        'order_id': order_id,
                    },
                    UpdateExpression="set order.selection=:a, order_status=:b",
                    ExpressionAttributeValues={
                        ':a': selection_list[input],
                        ':b': 'size'
                    },
                    ReturnValues="UPDATED_NEW"
                )
                return respond(None, response)

            elif order['Item']['order_status'] == 'size':
                size_list = order['Item']['order']['size']
                response = order_table.update_item(
                    Key={
                        'order_id': order_id,
                    },
                    UpdateExpression="set order.size=:a, order_status=:b",
                    ExpressionAttributeValues={
                        ':a': size_list[input],
                        ':b': 'processing'
                    },
                    ReturnValues="UPDATED_NEW"
                )
                return respond(None, response)

            return respond(None, "empty query")


        # elif operation == "DELETE":
        #     payload = event['body']
        #     dynamo = boto3.resource('dynamodb').Table(payload['TableName'])
        #     response = dynamo.delete_item(
        #         Key={
        #             'menu_id': payload['menu_id']
        #         }
        #     )
        #     return respond(None, response)
        else:
            return respond(ValueError('Unsupported PUT "{}"'.format(operation)));
    else:
        return respond(ValueError('Unsupported method "{}"'.format(operation)))